# The-JavaScript-Workshop

## Chapter 02

### Exercise 2.01: Creating a Working Project Directory 
*does not have a code file*
