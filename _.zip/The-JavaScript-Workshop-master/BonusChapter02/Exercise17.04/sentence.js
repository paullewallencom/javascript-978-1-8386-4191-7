let validateString = function(value) {
};
export {validateString};