## How to use

1. Install all the node packages by executing :

`npm i`

2. Run the dev server using following command :

`npm start`

3. Open multiple instances of [localhost:3000](https://localhost:3000) and start chatting.