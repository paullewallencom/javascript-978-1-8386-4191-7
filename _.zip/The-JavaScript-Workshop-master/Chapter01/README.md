# The-JavaScript-Workshop

## Chapter 01

### Chapter 01 does not contain any external files. This folder is intentionally empty. 
