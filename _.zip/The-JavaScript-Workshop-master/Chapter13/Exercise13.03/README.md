# Example of Inheritance

## How to use
- Run `node humans.js`
