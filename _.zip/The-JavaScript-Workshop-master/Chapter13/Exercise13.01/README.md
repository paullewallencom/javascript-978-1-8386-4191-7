# Example of Procedural Programming

## How to use
- Run `node procedural.js`
