# Calculator App
#### Both procedural and Object-oriented way

## How to use
- node oop.js
- node procedural.js