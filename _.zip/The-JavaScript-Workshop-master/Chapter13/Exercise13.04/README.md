# Example of Prototypical Inheritance

## How to use
- Run `node proto_inheritance_1.js`
- Run `node proto_inheritance_2.js`


## Expected Result
Output of both must be same.