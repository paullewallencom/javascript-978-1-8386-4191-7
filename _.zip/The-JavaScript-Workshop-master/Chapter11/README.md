# The-JavaScript-Workshop

## Chapter 11

### Chapter 11 has no code files for the exercises as the instructions include typing either into the console or a web site.
