export default () => {
  [1, 2, 3].map((value) => console.log("Mapping value ", value));
};