import mapper from "./module";
mapper();